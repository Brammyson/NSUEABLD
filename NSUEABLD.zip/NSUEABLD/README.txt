Thank you for playing Newest Super Ultra Epic Awesome Brammy Land Deluxe!

> First of all, you will need a Homebrewed Wii/WiiU with Riivolution installed. There are enough
tutorials online if you want to know how to homebrew your Wii/Wiiu.

> If your Wii/Wiiu is Homebrewed and Riivolution is installed, simply just drop the folders
"riivolution" and "NewestSuperUltraEpicAwesomeBrammyLandDeluxe" onto the root of your SD card.

> If you are having any trouble getting this to work, don't be afraid hitting me up on Twitter
or Discord.



>>>Socials<<<

Twitter: @Brammyson
Discord: Brammyson#6151
Twitch: Brammyson
Youtube: Speedrun channel Brammyson







All rights are owned by Nintendo